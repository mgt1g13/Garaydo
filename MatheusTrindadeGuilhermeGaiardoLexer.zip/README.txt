Para rodar o código, basta:

python3 Lexer.py [nome_do_arquivo_de_entrada]

Ex: python3 Lexer.py Teste.gg

O programa é um analisador léxico para C.
O código lê um arquivo fonte escrito em C (mais especificamente um subconjunto de C) e gera os Tokens que serão utilizados futuramente para análise sintática e semântica.
